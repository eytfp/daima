package com.example.demo.mybatisinjection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * 编号7089
 */
@RestController
@RequestMapping("/sqli")
public class MybitsController {

    @Autowired
    private UserMapper userMapper;

    //orderby查询 http://localhost:7089/sqli/mybatis/orderby?sort=username
    @GetMapping("/mybatis/orderby")
    public List<User> orderbySql(@RequestParam("sort") String sort) {
        return userMapper.orderbyInjection(sort);
    }

    //in查询 http://localhost:7089/sqli/mybatis/in?params=1
    @GetMapping("/mybatis/in")
    public List<User> inSql(@RequestParam("params") String params) {
        return userMapper.inInjection(params);
    }

    //Like查询 http://localhost:7089/sqli/mybatis/like?username=admin
    @GetMapping("/mybatis/like")
    @ResponseBody
    public List<User> likeSql(@RequestParam("username") String username){
        return userMapper.likeInjection(username);
    }
}
