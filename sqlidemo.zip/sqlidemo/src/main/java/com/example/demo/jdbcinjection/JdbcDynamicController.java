package com.example.demo.jdbcinjection;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.sql.*;

/**
 * 编号7089
 * 动态拼接
 * http://localhost:7089/sqli/jdbc/dynamic?id=1
 */
@RestController
@RequestMapping("/sqli")
public class JdbcDynamicController {

    private static String driver = "com.mysql.jdbc.Driver";
    @Value("${spring.datasource.url}")
    private String url;
    @Value("${spring.datasource.username}")
    private String user;
    @Value("${spring.datasource.password}")
    private String password;

    @RequestMapping("/jdbc/dynamic")
    public String jdbcDynamic(@RequestParam("id") String id) throws ClassNotFoundException, SQLException {

        StringBuilder result = new StringBuilder();
        // 注册驱动
        Class.forName(driver);
        // 获取连接
        Connection conn = DriverManager.getConnection(url, user, password);
        Statement statement = conn.createStatement();
        //动态拼接字符串
        String sql = "select * from users where id = '" + id + "'";
        ResultSet rs = statement.executeQuery(sql);
        while (rs.next()) {
            String rsUsername = rs.getString("username");
            String rsPassword = rs.getString("password");
            String info = String.format("%s: %s\n", rsUsername, rsPassword);
            result.append(info);
        }
        rs.close();
        conn.close();
        return result.toString();
    }

    @RequestMapping("/jdbc/dynamic2")
    public String jdbcDynamicc(@RequestParam("id") int id) throws ClassNotFoundException, SQLException {

        StringBuilder result = new StringBuilder();
        // 注册驱动
        Class.forName(driver);
        // 获取连接
        Connection conn = DriverManager.getConnection(url, user, password);
        Statement statement = conn.createStatement();
        //动态拼接字符串
        String sql = "select * from users where id = '" + id + "'";
        ResultSet rs = statement.executeQuery(sql);
        while (rs.next()) {
            String rsUsername = rs.getString("username");
            String rsPassword = rs.getString("password");
            String info = String.format("%s: %s\n", rsUsername, rsPassword);
            result.append(info);
        }
        rs.close();
        conn.close();
        return result.toString();
    }
}
