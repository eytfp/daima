package com.example.demo.jdbcinjection;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.sql.*;

/**
 * 编号7089
 * 错误的预编译
 * http://localhost:7089/sqli/jdbc/preparestaement?username=admin
 * 安全代码
 * http://localhost:7089/sqli/jdbc/sec?username=admin
 */
@RestController
@RequestMapping("/sqli")
public class JdbcPrepareStatement {
    private static String driver = "com.mysql.jdbc.Driver";
    @Value("${spring.datasource.url}")
    private String url;
    @Value("${spring.datasource.username}")
    private String user;
    @Value("${spring.datasource.password}")
    private String password;

    @RequestMapping("/jdbc/sec")
    public String jdbcsec(@RequestParam("username") String username) throws SQLException, ClassNotFoundException {

        StringBuilder result = new StringBuilder();
        Class.forName(driver);
        Connection conn = DriverManager.getConnection(url, user, password);
        // 安全代码
        String sql = "select * from users where username = ?";
        PreparedStatement preparestatement = conn.prepareStatement(sql);
        preparestatement.setString(1, username);
        ResultSet rs = preparestatement.executeQuery();
        while (rs.next()) {
            String resUsername = rs.getString("username");
            String resPassword = rs.getString("password");
            String info = String.format("%s: %s\n", resUsername, resPassword);
            result.append(info);
        }
        rs.close();
        conn.close();
        return result.toString();
    }

    @RequestMapping("/jdbc/preparestaement")
    public String jdbcPrepare(@RequestParam("username") String username) throws ClassNotFoundException, SQLException {
        StringBuilder result = new StringBuilder();
        Class.forName(driver);
        Connection conn = DriverManager.getConnection(url, user, password);
        //没有正确使用预编译方式，SQL语句还是进行了动态拼接
        String sql = "select * from users where username = '" + username + "'";
        PreparedStatement preparestatement = conn.prepareStatement(sql);
        ResultSet rs = preparestatement.executeQuery();
        while (rs.next()) {
            String reUsername = rs.getString("username");
            String resPassword = rs.getString("password");
            String info = String.format("%s: %s\n", reUsername, resPassword);
            result.append(info);
        }
        rs.close();
        conn.close();
        return result.toString();
    }
}
