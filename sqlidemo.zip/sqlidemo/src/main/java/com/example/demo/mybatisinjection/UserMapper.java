package com.example.demo.mybatisinjection;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * 编号7089
 */
@Mapper
public interface UserMapper {

    List<User> orderbyInjection(@RequestParam("sort") String sort);

    @Select("select * from users where id in (${params})")
    List<User> inInjection(@Param("params")String params);

    List<User> likeInjection(@Param("username") String username);

    //Mybatis查询SQL语句的另一种使用注解方式，这也是存在SQL注入的。
    //@Select("select * from users where username = '${username}'")
    //List<User> likeInjection(@Param("username") String username);
}
